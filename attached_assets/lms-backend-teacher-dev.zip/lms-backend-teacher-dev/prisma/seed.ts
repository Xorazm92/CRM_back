// import { PrismaClient, UserRole } from '@prisma/client';
// import { teachers } from './teacher';

// const prisma = new PrismaClient();

// async function main() {
//   const role = await prisma.roles.create({
//     data: { role_name: UserRole.TEACHER, role_level: 1 },
//   });

//   for (const teacher of teachers) {
//     const Teacher = await prisma.user.create({
//       data: {
//         email: teacher.email,
//         password: teacher.password,
//         full_name: teacher.full_name,
//         role_id: UserRole.TEACHER,
//       },
//     });
//     console.log(Teacher);
//   }
// }

// main()
//   .then(async () => {
//     await prisma.$disconnect();
//   })
//   .catch(async (e) => {
//     console.error(e);
//     await prisma.$disconnect();
//     process.exit(1);
//   });
