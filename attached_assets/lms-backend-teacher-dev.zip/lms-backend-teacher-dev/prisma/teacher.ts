export const teachers = [
  {
    full_name: 'Jahongir',
    password: 'Jhondoe007!A',
    email: 'jaxongi454adwr@gmail.com',
  },
  {
    full_name: 'Shahzod',
    password: 'Shahzod123!B',
    email: 'shahzod9231@gmail.com',
  },
  {
    full_name: 'Bekzod',
    password: 'BekBek!987Z',
    email: 'bekzod.official22@mail.com',
  },
  {
    full_name: 'Azizbek',
    password: 'Aziz@2023#x',
    email: 'azizbek.rassulov89@gmail.com',
  },
  { full_name: 'Bobur', password: 'B0burKing*A', email: 'bobur_uzb@yahoo.com' },
  {
    full_name: 'Odilbek',
    password: 'Odil#9999z',
    email: 'odilbek999x@gmail.com',
  },
  {
    full_name: 'Sardor',
    password: 'Sardor$$W00',
    email: 'sardorwrestle7@gmail.com',
  },
  {
    full_name: 'Abbos',
    password: 'Abbos_22!C',
    email: 'abbos.tiger@hotmail.com',
  },
  {
    full_name: 'Farrux',
    password: 'Farrux007*A',
    email: 'farrux_dev@gmail.com',
  },
  {
    full_name: 'Jamshid',
    password: 'Jamshid!Z1x',
    email: 'jamshid_codez@mail.ru',
  },
  {
    full_name: 'Alisher',
    password: 'AliSh3r99$',
    email: 'alisher.boss@gmail.com',
  },
  {
    full_name: 'Islom',
    password: 'Islom##00q',
    email: 'islomka.official@gmail.com',
  },
  {
    full_name: 'Muhammad',
    password: 'Muh@mad321X',
    email: 'muhammad_ali@tutanota.com',
  },
  {
    full_name: 'Diyor',
    password: 'Diy0r!PassZ',
    email: 'diyorking123@mail.com',
  },
  { full_name: 'Umid', password: 'Umid@!777C', email: 'umid.2025@proton.me' },
  {
    full_name: 'Sherzod',
    password: 'Sherz0d@xY',
    email: 'sherzod_snake@gmail.com',
  },
  {
    full_name: 'Rustam',
    password: 'Rustam1999!',
    email: 'rustam_rider@gmail.com',
  },
  {
    full_name: 'Anvar',
    password: 'Anv@r$$Q1',
    email: 'anvar.nextdev@gmail.com',
  },
  {
    full_name: 'Temur',
    password: 'Temur_007!',
    email: 'temur.legend@gmail.com',
  },
  {
    full_name: 'Botir',
    password: 'Botir##a1Z',
    email: 'botir_alpha@gmail.com',
  },
];
