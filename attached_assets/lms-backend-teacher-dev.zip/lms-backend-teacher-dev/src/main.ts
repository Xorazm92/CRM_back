import Application from './api/app.service';
void Application.main();
