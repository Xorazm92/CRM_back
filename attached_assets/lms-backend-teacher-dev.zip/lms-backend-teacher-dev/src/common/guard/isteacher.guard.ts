import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { Observable } from 'rxjs';

@Injectable()
export class TeacherGuard implements CanActivate {
  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest();
    const req = request.user;

    if (
      req?.role == UserRole.TEACHER ||
      req?.role == UserRole.ADMIN ||
      req?.role == UserRole.MANAGER
    ) {
      return true;
    }
    return false;
  }
}
