export interface TokenI {
  refresh_token: string;
}
