import { registerAs } from '@nestjs/config';

export interface AppConfigI {
  port: number;
  doc_password: string;
}

export const appConfig = registerAs<AppConfigI>(
  'app',
  (): AppConfigI => ({
    port: +process.env.PORT,
    doc_password: process.env.DOC_PASS,
  }),
);
