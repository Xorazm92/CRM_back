import { registerAs } from '@nestjs/config';

export interface SMSConfigI {
  email: string;
  api: string;
  password: string;
}

export const smsConfig = registerAs<SMSConfigI>(
  'sms',
  (): SMSConfigI => ({
    email: process.env.ESKIZ_EMAIL,
    password: process.env.ESKIZ_TOKEN,
    api: process.env.ESKIZ_API,
  }),
);
