import { IsString, IsOptional } from 'class-validator';
export class SmsDto {
  @IsOptional()
  @IsString()
  from?: string;

  @IsOptional()
  @IsString()
  message?: string;

  @IsOptional()
  @IsString()
  mobile_phone?: string;
}
