import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';
import { SmsDto } from './sms.dto';

@Injectable()
export class SmsService {
  private readonly smsApi: string;
  private readonly smsPassword: string;
  private readonly smsEmail: string;

  constructor(private readonly configService: ConfigService) {
    this.smsApi = this.configService.get<string>('sms.api')!;
    this.smsPassword = this.configService.get<string>('sms.password')!;
    this.smsEmail = this.configService.get<string>('sms.email')!;
  }

  async fetchEskizToken() {
    const { data } = await axios.post(`${this.smsApi}/auth/login`, {
      email: this.smsEmail,
      password: this.smsPassword,
    });
    return data.data.token;
  }
  async sendSms(payload: SmsDto) {
    const token = await this.fetchEskizToken();
    const post = await axios.post(
      `${this.smsApi}/message/sms/send`,
      {
        mobile_phone: payload.mobile_phone,
        from: '4546',
        message: 'Bu Eskiz dan test',
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    );
    return post.data;
  }
}
