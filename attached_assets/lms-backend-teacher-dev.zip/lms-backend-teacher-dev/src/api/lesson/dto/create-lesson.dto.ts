import { IsString, IsUUID, IsDateString } from 'class-validator';

export class CreateLessonDto {
  @IsUUID()
  group_id: string;

  @IsString()
  topic: string;

  @IsDateString()
  lesson_date: string;

  @IsString()
  recording_path: string;
}
