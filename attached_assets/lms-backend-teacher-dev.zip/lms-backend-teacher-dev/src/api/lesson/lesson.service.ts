import { HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { CreateLessonDto } from './dto/create-lesson.dto';
import { UpdateLessonDto } from './dto/update-lesson.dto';
import { PrismaService } from '@/common/prisma/prisma.service';

@Injectable()
export class LessonService {
  constructor(private readonly prisma: PrismaService) {}
  async create(createLessonDto: CreateLessonDto) {
    const newLesson = await this.prisma.lessons.create({
      data: createLessonDto,
    });
    return {
      status_code: HttpStatus.CREATED,
      message: 'Lesson created successfully',
    };
  }

  async findAll(query: 'asc' | 'desc') {
    const data = await this.prisma.lessons.findMany({
      orderBy: { created_at: query },
    });
    if (data.length == 0) {
      throw new NotFoundException('Lesson not found');
    }
    return {
      status_code: HttpStatus.OK,
      message: 'All Lesson',
      data: data,
    };
  }

  async findOne(id: string) {
    const data = await this.prisma.lessons.findFirst({
      where: { lesson_id: id },
    });
    if (!data) {
      throw new NotFoundException('Lesson not found');
    }
    return {
      status_code: HttpStatus.OK,
      message: 'One Lesson',
      data: {
        ...data,
      },
    };
  }

  async update(id: string, updateLessonDto: UpdateLessonDto) {
    const data = await this.prisma.lessons.findFirst({
      where: { lesson_id: id },
    });
    if (!data) {
      throw new NotFoundException('Lesson not found');
    }
    await this.prisma.lessons.update({
      where: {
        lesson_id: id,
      },
      data: {
        ...updateLessonDto,
        updated_at: new Date(),
      },
    });
    return {
      status_code: HttpStatus.NO_CONTENT,
      message: 'Lesson updated successfully',
    };
  }

  async remove(id: string) {
    const data = await this.prisma.lessons.findFirst({
      where: { lesson_id: id },
    });
    if (!data) {
      throw new NotFoundException('Lesson not found or deleted before');
    }
    return {
      status_code: HttpStatus.NO_CONTENT,
      message: 'Lesson deleted successfully',
    };
  }
}
