import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsNotEmpty, IsString } from 'class-validator';

export class CreateAssignmentDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  lesson_id: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({
    description: 'Due date (ISO yoki DD.MM.YYYY formatida)',
    examples: ['2023-12-31T23:59:59Z', '2023.12.31'],
  })
  @Transform(({ value }) => {
    if (typeof value === 'string' && value.includes('.')) {
      const [day, month, year] = value.split('.');
      return new Date(`${year}-${month}-${day}`);
    }
    return new Date(value);
  })
  due_date: Date;
}
