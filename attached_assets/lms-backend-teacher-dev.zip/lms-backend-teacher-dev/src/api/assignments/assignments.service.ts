import { HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { CreateAssignmentDto } from './dto/create-assignment.dto';
import { UpdateAssignmentDto } from './dto/update-assignment.dto';
import { PrismaService } from '@/common/prisma/prisma.service';
import { PaginationDto } from '@/common/dto';

@Injectable()
export class AssignmentsService {
  constructor(private readonly prisma: PrismaService) {}
  async create(createAssignmentDto: CreateAssignmentDto) {
    const newAssignment = await this.prisma.assignments.create({
      data: createAssignmentDto,
    });
    return {
      status_code: HttpStatus.CREATED,
      message: 'Assignment created successfully',
    };
  }

  async findAll(query: PaginationDto) {
    const { page, limit } = query;
    const skip = (page - 1) * limit;

    const [data, count] = await Promise.all([
      this.prisma.assignments.findMany({
        skip,
        take: limit,
      }),
      this.prisma.assignments.count(),
    ]);

    if (data.length == 0) {
      throw new NotFoundException('Assignments not found');
    }
    return {
      status_code: HttpStatus.OK,
      message: 'All Assignments',
      data: data,
      filter: {
        limit,
        pageSize: Math.ceil(count / limit),
        totalItems: count,
      },
    };
  }

  async findOne(id: string) {
    const data = await this.prisma.assignments.findFirst({
      where: { assignment_id: id },
    });
    if (!data) {
      throw new NotFoundException('Assignment not found');
    }
    return {
      status_code: HttpStatus.OK,
      message: 'One Assignment',
      data: {
        ...data,
      },
    };
  }

  async update(id: string, updateAssignmentDto: UpdateAssignmentDto) {
    const data = await this.prisma.assignments.findFirst({
      where: { assignment_id: id },
    });
    if (!data) {
      throw new NotFoundException('Assignment not found');
    }
    await this.prisma.assignments.update({
      where: {
        assignment_id: id,
      },
      data: {
        ...updateAssignmentDto,
        updated_at: new Date(),
      },
    });
    return {
      status_code: HttpStatus.NO_CONTENT,
      message: 'Assignments updated successfully',
    };
  }

  async remove(id: string) {
    const data = await this.prisma.assignments.findFirst({
      where: { assignment_id: id },
    });
    if (!data) {
      throw new NotFoundException('Assignments not found or deleted before');
    }
    return {
      status_code: HttpStatus.NO_CONTENT,
      message: 'Assignments deleted successfully',
    };
  }
}
