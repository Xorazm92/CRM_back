import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { appConfig, jwtConfig, smsConfig } from 'src/config';
import { UserModule } from './user/user.module';
import { JwtModule } from '@nestjs/jwt';
import { AuthModule } from './auth/auth.module';
import { CustomLogger } from 'src/infrastructure/lib/custom-logger/logger.service';
import { WinstonModule } from 'nest-winston';
import { AttendanceModule } from './attendance/attendance.module';
import { AssignmentsModule } from './assignments/assignments.module';
import { APP_GUARD } from '@nestjs/core';
import { AuthGuard } from '@/common/guard/auth.guard';
import { TeacherGuard } from '@/common/guard/isteacher.guard';
import { SubmissionsModule } from './submissions/submissions.module';
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
import { FileuploadModule } from './fileupload/fileupload.module';
import { LessonModule } from './lesson/lesson.module';
import { RedisModule } from './redis/redis.module';

@Module({
  imports: [
    ThrottlerModule.forRoot({
      throttlers: [
        {
          ttl: 60000,
          limit: 10,
        },
      ],
    }),
    ConfigModule.forRoot({
      load: [appConfig, jwtConfig, smsConfig],
      isGlobal: true,
    }),
    WinstonModule.forRoot({}),
    UserModule,
    AuthModule,
    AttendanceModule,
    AssignmentsModule,
    SubmissionsModule,
    FileuploadModule,
    LessonModule,
    RedisModule,
  ],
  controllers: [],
  providers: [
    PrismaService,
    CustomLogger,
    {
      provide: APP_GUARD,
      useClass: AuthGuard,
    },
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
  exports: [CustomLogger],
})
export class AppModule {}
