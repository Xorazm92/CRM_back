import { NestFactory } from '@nestjs/core';
import { HttpStatus, ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { AllExceptionsFilter } from '../infrastructure/lib/exception';
import * as basicAuth from 'express-basic-auth';
import { AppConfigI } from '../config';
import { ConfigService } from '@nestjs/config';
import { NestExpressApplication } from '@nestjs/platform-express';
import helmet from 'helmet';
import { CustomLogger } from 'src/infrastructure/lib/custom-logger/logger.service';
import { join } from 'path';

export default class Application {
  public static async main(): Promise<void> {
    const app = await NestFactory.create<NestExpressApplication>(AppModule, {
      cors: true,
    });
    const logger = app.get(CustomLogger);
    const configService = app.get(ConfigService);
    const appConfig = configService.get<AppConfigI>('app');
    app.useGlobalFilters(new AllExceptionsFilter());
    app.use(helmet());
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY,
        transform: true,
      }),
    );
    const api = '/api/v1';
    const swaggerApi = '/api/docs';
    app.use(
      swaggerApi,
      basicAuth({
        users: { admin: appConfig.doc_password },
        challenge: true,
      }),
    );
    app.useStaticAssets(join(__dirname, '..', 'uploads'), {
      prefix: '/api/v1/static/',
    });
    app.setGlobalPrefix(api);
    const config_swagger = new DocumentBuilder()
      .setTitle('LMS')
      .setVersion('1.0')
      .addBearerAuth({
        type: 'http',
        scheme: 'Bearer',
        in: 'Header',
      })
      .build();
    const documentFactory = () =>
      SwaggerModule.createDocument(app, config_swagger);
    SwaggerModule.setup(swaggerApi, app, documentFactory);
    await app.listen(appConfig.port ?? 3000, () => {
      logger.log(`Backend URL: http://localhost:${appConfig.port}/api/v1`);
      logger.log(`Swagger URL: http://localhost:${appConfig.port}/api/docs`);
      logger.log(Date.now());
    });
  }
}
