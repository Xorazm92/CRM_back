import {
  BadRequestException,
  HttpStatus,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { CreateSubmissionDto } from './dto/create-submission.dto';
import { UpdateSubmissionDto } from './dto/update-submission.dto';
import { PrismaService } from '@/common/prisma/prisma.service';
import { PaginationDto } from '@/common/dto';

@Injectable()
export class SubmissionsService {
  constructor(private readonly prismaService: PrismaService) {}

  async create(createSubmissionDto: CreateSubmissionDto) {
    try {
      const assigment = await this.prismaService.assignments.findFirst({
        where: { assignment_id: createSubmissionDto.assignment_id },
      });
      const student = await this.prismaService.user.findFirst({
        where: { user_id: createSubmissionDto.student_id },
      });
      const teacher = await this.prismaService.user.findFirst({
        where: { user_id: createSubmissionDto.graded_by },
      });

      if (!assigment || !student || !teacher) {
        throw new NotFoundException(
          'Assigment or student or teacher id not found',
        );
      }

      const newSubmission = await this.prismaService.submissions.create({
        data: createSubmissionDto,
      });

      return {
        status_code: HttpStatus.CREATED,
        message: 'Submission created successfully',
        data: newSubmission,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async findAll(query: PaginationDto) {
    try {
      const { page, limit } = query;
      const skip = (page - 1) * limit;

      const [data, count] = await Promise.all([
        this.prismaService.submissions.findMany({
          skip,
          take: limit,
        }),
        this.prismaService.submissions.count(),
      ]);
      if (data.length === 0) {
        throw new NotFoundException('Submissions not found');
      }

      return {
        status_code: HttpStatus.OK,
        messsage: 'All Submissions fetched successfully',
        data: data,
        filter: {
          limit,
          pageSize: Math.ceil(count / limit),
          totalItems: count,
        },
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async findOne(id: string) {
    try {
      const data = await this.prismaService.submissions.findFirst({
        where: { submission_id: id },
      });

      if (!data) {
        throw new NotFoundException('Submission not found');
      }

      return {
        status_code: HttpStatus.OK,
        message: 'One Submission fetched successfully',
        data: { ...data },
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async update(id: string, updateSubmissionDto: UpdateSubmissionDto) {
    try {
      const submissionData = await this.prismaService.submissions.findFirst({
        where: { submission_id: id },
      });

      if (!submissionData) {
        throw new NotFoundException('Submission not found');
      }

      if (updateSubmissionDto.assignment_id) {
        const assigmentId = await this.prismaService.assignments.findFirst({
          where: { assignment_id: updateSubmissionDto.assignment_id },
        });

        if (!assigmentId) {
          throw new NotFoundException('Assigment not found');
        }
      } else if (updateSubmissionDto.student_id) {
        const studentId = await this.prismaService.user.findFirst({
          where: { user_id: updateSubmissionDto.student_id },
        });

        if (!studentId) {
          throw new NotFoundException('Student not found');
        }
      } else if (updateSubmissionDto.graded_by) {
        const teacherId = await this.prismaService.user.findFirst({
          where: { user_id: updateSubmissionDto.graded_by },
        });

        if (!teacherId) {
          throw new NotFoundException('Teacher(graded_by) not found');
        }
      }

      const updatedSubmission = await this.prismaService.submissions.update({
        where: { submission_id: id },
        data: updateSubmissionDto,
      });

      return {
        status_code: HttpStatus.OK,
        message: 'Submission updated successfully',
        data: updatedSubmission,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async remove(id: string) {
    try {
      const data = await this.prismaService.submissions.findFirst({
        where: { submission_id: id },
      });

      if (!data) {
        throw new NotFoundException('Submission not found');
      }

      // await this.prismaService.submissions.delete({
      //   where: { submission_id: id },
      // });

      return {
        status_code: HttpStatus.OK,
        message: 'Submission deleted successfully',
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }
}
