import { ApiProperty } from '@nestjs/swagger';
import { IsISO8601, IsNotEmpty, IsString, IsUUID } from 'class-validator';

export class CreateSubmissionDto {
  @ApiProperty({
    type: String,
    description: 'Assigment id',
    example: '110ec58a-a0f2-4ac4-8393-c866d813b8d1',
  })
  @IsNotEmpty()
  @IsString()
  @IsUUID()
  assignment_id: string;

  @ApiProperty({
    type: String,
    description: 'Student id',
    example: '110ec58a-a0f2-4ac4-8393-c866d813b8d1',
  })
  @IsNotEmpty()
  @IsString()
  @IsUUID()
  student_id: string;

  @ApiProperty({
    type: String,
    description: 'Teacher id',
    example: '110ec58a-a0f2-4ac4-8393-c866d813b8d1',
  })
  @IsNotEmpty()
  @IsString()
  @IsUUID()
  graded_by: string;

  @ApiProperty({
    type: String,
    description: 'File path or link',
    example:
      'https://www.istockphoto.com/photo/happy-smart-and-cute-boy-doing-homework-with-the-help-of-his-dad-at-home-education-gm2040987620-562686649?utm_source=pixabay&utm_medium=affiliate&utm_campaign=sponsored_image&utm_content=srp_topbanner_media&utm_term=homework',
  })
  @IsNotEmpty()
  @IsString()
  file_path: string;

  @ApiProperty({
    type: String,
    description: 'Grade',
    example: 'A or 5 or 100, other.',
  })
  @IsNotEmpty()
  @IsString()
  grade: string;

  @ApiProperty({
    type: String,
    description: 'Graded at',
    example: '2019-02-29',
  })
  @IsNotEmpty()
  @IsString()
  @IsISO8601()
  graded_at: string;

  @ApiProperty({
    type: String,
    description: 'Feedbacks for submission',
    example: "It's good, but you can make it better:)",
  })
  @IsNotEmpty()
  @IsString()
  feedback: string;
}
