import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  HttpCode,
  HttpStatus,
  Query,
  ParseUUIDPipe,
} from '@nestjs/common';
import { SubmissionsService } from './submissions.service';
import { CreateSubmissionDto } from './dto/create-submission.dto';
import { UpdateSubmissionDto } from './dto/update-submission.dto';
import {
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { PaginationDto } from '@/common/dto';

@ApiTags('Submissions')
@Controller('submissions')
export class SubmissionsController {
  constructor(private readonly submissionsService: SubmissionsService) {}

  @Post()
  @ApiOperation({
    summary: 'Create submission',
    description: 'Create submission for the assigment',
  })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Successfully created',
    schema: {
      example: {
        status_code: HttpStatus.CREATED,
        message: 'Submission created successfully',
        data: {
          assigment_id: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          student_id: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          graded_by: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          file_path:
            'https://www.istockphoto.com/photo/happy-smart-and-cute-boy-doing-homework-with-the-help-of-his-dad-at-home-education-gm2040987620-562686649?utm_source=pixabay&utm_medium=affiliate&utm_campaign=sponsored_image&utm_content=srp_topbanner_media&utm_term=homework',
          grade: '86',
          graded_at: '2019-02-29',
          feedback: 'task completed successfully and all requires initialized',
        },
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Assigment or student or teacher id not found',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Assigment or student or teacher id not found',
      },
    },
  })
  create(@Body() createSubmissionDto: CreateSubmissionDto) {
    return this.submissionsService.create(createSubmissionDto);
  }

  @Get()
  @ApiOperation({
    summary: 'Get All Submissions',
    description: 'Get All Submissions',
  })
  @ApiOkResponse({
    status: HttpStatus.OK,
    description: 'All Submissions fetched successfully',
    schema: {
      example: {
        status_code: HttpStatus.OK,
        message: 'All Submissions fetched successfully',
        data: [],
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Submissions not found',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Submission not found',
      },
    },
  })
  @HttpCode(HttpStatus.OK)
  findAll(@Query() query: PaginationDto) {
    return this.submissionsService.findAll(query);
  }

  @Get(':id')
  @ApiOperation({
    summary: 'Get one submission',
    description: 'Get one submission by id',
  })
  @ApiParam({ name: 'id', type: String, description: 'Submission id' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'One Submission fetched successfully',
    schema: {
      example: {
        status_code: HttpStatus.OK,
        message: 'One Submission fetched successfully',
        data: {
          assigment_id: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          student_id: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          graded_by: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          file_path:
            'https://www.istockphoto.com/photo/happy-smart-and-cute-boy-doing-homework-with-the-help-of-his-dad-at-home-education-gm2040987620-562686649?utm_source=pixabay&utm_medium=affiliate&utm_campaign=sponsored_image&utm_content=srp_topbanner_media&utm_term=homework',
          grade: '86',
          graded_at: '2019-02-29',
          feedback: 'task completed successfully and all requires initialized',
        },
        filter: {
          limit: 10,
          pageSize: 6,
          totalItems: 53,
        },
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Submission not found',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Submission not found',
      },
    },
  })
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.submissionsService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({
    summary: 'Update submission',
    description: 'Update submission by id',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Submission updated successfully',
    schema: {
      example: {
        status_code: HttpStatus.OK,
        message: 'Submission updated successfully',
        data: {
          assigment_id: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          student_id: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          graded_by: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          file_path:
            'https://www.istockphoto.com/photo/happy-smart-and-cute-boy-doing-homework-with-the-help-of-his-dad-at-home-education-gm2040987620-562686649?utm_source=pixabay&utm_medium=affiliate&utm_campaign=sponsored_image&utm_content=srp_topbanner_media&utm_term=homework',
          grade: '86',
          graded_at: '2019-02-29',
          feedback: 'task completed successfully and all requires initialized',
        },
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Submission not found',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Submission not found',
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Assigment not found',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Assigment not found',
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Student not found',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Student not found',
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Teacher(graded_by) not found',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Teacher(graded_by) not found',
      },
    },
  })
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() updateSubmissionDto: UpdateSubmissionDto,
  ) {
    return this.submissionsService.update(id, updateSubmissionDto);
  }

  @Delete(':id')
  @ApiOperation({
    summary: 'Delete submission',
    description: 'Delete submission by id',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Successfully deleted',
    schema: {
      example: {
        status_code: HttpStatus.OK,
        message: 'Submission deleted successfully',
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Submission not found',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Submission not found',
      },
    },
  })
  remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.submissionsService.remove(id);
  }
}
