import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { GuardModule } from 'src/common/guard/jwt.module';
import { UserModule } from '../user/user.module';
import { SmsService } from 'src/infrastructure/lib/sms/sms.service';

@Module({
  imports: [GuardModule, UserModule],
  controllers: [AuthController],
  providers: [AuthService, SmsService],
})
export class AuthModule {}
