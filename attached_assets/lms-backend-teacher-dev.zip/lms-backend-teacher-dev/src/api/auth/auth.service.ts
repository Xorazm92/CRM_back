import { BadRequestException, Injectable } from '@nestjs/common';
import { TokenI } from 'src/common/interface';
import { UserService } from '../user/user.service';
import { SmsService } from 'src/infrastructure/lib/sms/sms.service';
import { SmsDto } from 'src/infrastructure/lib/sms/sms.dto';
import { CreateAdminDto } from './dto/create-auth.dto';
import { LoginAuthDto } from './dto/login-auth.dto';
import { TokenService } from '@/common/guard/jwt.service';
@Injectable()
export class AuthService {
  constructor(
    private readonly userService: UserService,
    private readonly jwtService: TokenService,
    private readonly smsService: SmsService,
  ) {}

  async signUp(createAuthDto: CreateAdminDto) {
    return await this.userService.create(createAuthDto);
  }

  async signIn(createLoginAuthDto: LoginAuthDto) {
    try {
      const user = await this.userService.findByEmail(createLoginAuthDto);
      const { data } = user;

      const payload = { role: data.role, email: data.email };

      const access_token = this.jwtService.createAccessToken(payload);
      const refresh_token = this.jwtService.createRefreshToken(payload);
      return {
        message: 'User found successfully',
        status_code: 200,
        access_token,
        refresh_token,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async refreshToken(createAccessTokenDto: TokenI) {
    const data = await this.jwtService.verifyRefreshToken(
      createAccessTokenDto.refresh_token,
    );

    const payload = { user_id: data.user_id, email: data.email };
    const access_token = this.jwtService.createAccessToken(payload);
    const refresh_token = this.jwtService.createRefreshToken(payload);

    return {
      message: 'User found successfully',
      status_code: 200,
      access_token,
      refresh_token,
    };
  }

  async sendOTP(dto: SmsDto) {
    const data = await this.smsService.sendSms(dto);
    return data;
  }
}
