import { PartialType } from '@nestjs/swagger';
import { CreateAdminDto } from './create-auth.dto';

export class UpdateAdminDto extends PartialType(CreateAdminDto) {
  full_name?: string;
  email?: string;
  password?: string;
}
