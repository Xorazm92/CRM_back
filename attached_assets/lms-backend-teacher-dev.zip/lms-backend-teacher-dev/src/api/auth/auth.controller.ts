import { Controller, Get, Post, Body, HttpStatus } from '@nestjs/common';
import { AuthService } from './auth.service';
import { TokenI } from 'src/common/interface';
import { SmsDto } from 'src/infrastructure/lib/sms/sms.dto';
import { CreateAdminDto } from './dto/create-auth.dto';
import { LoginAuthDto } from './dto/login-auth.dto';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';

@ApiTags('admin')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @ApiOperation({
    summary: 'Sign up',
    description: 'Sign up as admin or teacher or student',
  })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Successfully signed up',
    schema: {
      example: {
        status_code: HttpStatus.CREATED,
        message: 'User created successfully',
        data: {},
      },
    },
  })
  @ApiResponse({
    status: 400,
    description: 'User already exists',
    schema: {
      example: {
        status_code: HttpStatus.BAD_REQUEST,
        message: 'User already exists',
        data: {},
      },
    },
  })
  @Post('signUp')
  signUp(@Body() createAuthDto: CreateAdminDto) {
    return this.authService.signUp(createAuthDto);
  }

  @ApiOperation({
    summary: 'Sign in',
    description: 'Sign in as admin or teacher or student',
  })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'User found successfully',
    schema: {
      example: {
        status_code: HttpStatus.OK,
        message: 'User found successfully',
        data: {
          message: 'User found successfully',
          status_code: 200,
          access_token:
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyMyIsImVtYWlsIjoiYWRtaW5AZXhhbXBsZS5jb20iLCJyb2xlIjoiQURNSU4iLCJpYXQiOjE2OTk3MDc2MDAsImV4cCI6MTY5OTcxMTIwMH0.aFQmtVUtoIE0XQfFW0a-QTcT8coYe4eLCm3JmL_zR1o',
          refresh_token:
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyMyIsImVtYWlsIjoiYWRtaW5AZXhhbXBsZS5jb20iLCJyb2xlIjoiQURNSU4iLCJpYXQiOjE2OTk3MDc2MDAsImV4cCI6MTY5OTcxMTIwMH0.aFQmtVUtoIE0XQfFW0a-QTcT8coYe4eLCm3JmL_zR1o',
        },
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Invalid email or password',
    schema: {
      example: {
        status_code: HttpStatus.NOT_FOUND,
        message: 'Invalid email or password',
        data: {},
      },
    },
  })
  @Post('signIn')
  signIn(@Body() createAuthDto: LoginAuthDto) {
    return this.authService.signIn(createAuthDto);
  }

  @ApiOperation({
    summary: 'Refresh token',
    description: 'Refresh token for admin or teacher or student',
  })

  @ApiResponse({
    status: HttpStatus.OK,
    description: 'User found successfully',
    schema: {
      example: {
        status_code: HttpStatus.OK,
        message: 'User found successfully',
        data: {
          message: 'User found successfully',
          status_code: HttpStatus.OK,
          access_token:
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyMyIsImVtYWlsIjoiYWRtaW5AZXhhbXBsZS5jb20iLCJyb2xlIjoiQURNSU4iLCJpYXQiOjE2OTk3MDc2MDAsImV4cCI6MTY5OTcxMTIwMH0.aFQmtVUtoIE0XQfFW0a-QTcT8coYe4eLCm3JmL_zR1o',
          refresh_token:
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyMyIsImVtYWlsIjoiYWRtaW5AZXhhbXBsZS5jb20iLCJyb2xlIjoiQURNSU4iLCJpYXQiOjE2OTk3MDc2MDAsImV4cCI6MTY5OTcxMTIwMH0.aFQmtVUtoIE0XQfFW0a-QTcT8coYe4eLCm3JmL_zR1o',
        },
      },
    },
  })
  @Post('refreshToken')
  refreshToken(@Body() createAuthDto: TokenI) {
    return this.authService.refreshToken(createAuthDto);
  }

  @Get('send-otp')
  sendOTP(@Body() data: SmsDto) {
    return this.authService.sendOTP(data);
  }
}
