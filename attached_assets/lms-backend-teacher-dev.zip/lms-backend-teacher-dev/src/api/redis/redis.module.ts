import { Module } from '@nestjs/common';
import Redis from 'ioredis';


@Module({
  providers:[
    {
      provide:'REDIS_CLIENT',
      useFactory:async ()=>{
        const client=new Redis()
        client.on('connect',()=>{
          console.log('connect to redis ✅');
        })
        client.on('error',(err)=>{
          console.error('Error Redis ❌',err);
        })
        return client
      }
    }
  ]
})
export class RedisModule {}
