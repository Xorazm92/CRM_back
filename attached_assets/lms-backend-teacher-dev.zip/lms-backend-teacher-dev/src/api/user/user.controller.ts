import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  HttpStatus,
  ParseUUIDPipe,
} from '@nestjs/common';
import {
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiBody,
  ApiTags,
} from '@nestjs/swagger';
import { UserService } from './user.service';
import { Prisma } from '@prisma/client';
import { UpdateAdminDto } from '../auth/dto/update-auth.dto';
import { Public } from '@/common/decorator';

@ApiTags('User')
@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @ApiOperation({ summary: 'Get all users' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Users found successfully',
    schema: {
      example: {
        message: 'Users found successfully',
        status_code: HttpStatus.OK,
        data: [],
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Users not found',
    schema: {
      example: {
        message: 'Users not found',
        status_code: HttpStatus.NOT_FOUND,
      },
    },
  })
  @Public()
  @Get()
  findAll() {
    return this.userService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a user by ID' })
  @ApiParam({ name: 'id', type: String, description: 'User ID' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'User found successfully',
    schema: {
      example: {
        message: 'User found successfully',
        status_code: HttpStatus.OK,
        data: {
          user_id: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          email: 'admin@example.com',
          full_name: 'Jane Doe',
          role_id: 'r1x2y3z4-w5v6-7890-role-0987654321gh',
          created_at: '2025-04-07T10:20:30.000Z',
          updated_at: '2025-04-07T12:00:00.000Z',
        },
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'User not found',
    schema: {
      example: { message: 'User not found', status_code: HttpStatus.NOT_FOUND },
    },
  })
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.userService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update user by id' })
  @ApiParam({ name: 'id', type: String, description: 'User ID' })
  @ApiBody({ type: UpdateAdminDto })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'User updated successfully',
    schema: {
      example: {
        message: 'User updated successfully',
        status_code: HttpStatus.OK,
        data: {
          user_id: 'a1b2c3d4-e5f6-7890-abcd-1234567890ef',
          email: 'admin@example.com',
          full_name: 'Jane Doe',
          role_id: 'r1x2y3z4-w5v6-7890-role-0987654321gh',
          created_at: '2025-04-07T10:20:30.000Z',
          updated_at: '2025-04-07T12:00:00.000Z',
        },
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'User not found',
    schema: {
      example: { message: 'User not found', status_code: HttpStatus.NOT_FOUND },
    },
  })
  update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() updateUserDto: UpdateAdminDto,
  ) {
    return this.userService.update(id, updateUserDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a user by ID' })
  @ApiParam({ name: 'id', type: String, description: 'User ID' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'User deleted successfully',
    schema: {
      example: {
        message: 'User deleted successfully',
        status_code: HttpStatus.OK,
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'User not found',
    schema: {
      example: { message: 'User not found', status_code: HttpStatus.NOT_FOUND },
    },
  })
  remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.userService.remove(id);
  }
}
