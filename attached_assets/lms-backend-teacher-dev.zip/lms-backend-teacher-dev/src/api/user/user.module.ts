import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CustomLogger } from 'src/infrastructure/lib/custom-logger/logger.service';
import { TeacherGuard } from '@/common/guard/isteacher.guard';
import { APP_GUARD } from '@nestjs/core';

@Module({
  controllers: [UserController],
  providers: [UserService, PrismaService, CustomLogger],
  exports: [UserService],
})
export class UserModule {}
