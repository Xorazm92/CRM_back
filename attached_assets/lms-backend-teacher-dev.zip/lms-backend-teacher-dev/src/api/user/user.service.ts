import { BadRequestException, Injectable } from '@nestjs/common';
import { User, Prisma, UserRole } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CustomLogger } from 'src/infrastructure/lib/custom-logger/logger.service';
import { CreateAdminDto } from '../auth/dto/create-auth.dto';
import { LoginAuthDto } from '../auth/dto/login-auth.dto';
import { BcryptEncryption } from 'src/infrastructure/lib/bcrypt';
import { UpdateAdminDto } from '../auth/dto/update-auth.dto';

@Injectable()
export class UserService {
  constructor(
    private readonly prismaservice: PrismaService,
    private readonly logger: CustomLogger,
  ) {}

  async create(createUserDto: CreateAdminDto) {
    try {
      const existingUser = await this.prismaservice.user.findUnique({
        where: { email: createUserDto.email },
      });

      if (existingUser) {
        throw new BadRequestException('User already exists');
      }

      const hashPassword = await BcryptEncryption.encrypt(
        createUserDto.password,
      );
      const user = await this.prismaservice.user.create({
        data: {
          email: createUserDto.email,
          password: hashPassword,
          full_name: createUserDto.full_name,
          role: createUserDto.role,
        },
      });
      return {
        message: 'User created successfully',
        status_code: 200,
        data: user,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async findAll() {
    try {
      const users = await this.prismaservice.user.findMany();
      if (!users) {
        throw new BadRequestException('Users not found');
      }

      return {
        message: 'Users found successfully',
        status_code: 200,
        data: users,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async findOne(id: string) {
    try {
      const user = await this.prismaservice.user.findUnique({
        where: { user_id: id },
      });

      if (!user) {
        throw new BadRequestException('User not found');
      }

      return {
        message: 'User found successfully',
        status_code: 200,
        data: user,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async findByEmail(loginDto: LoginAuthDto) {
    const user = await this.prismaservice.user.findUnique({
      where: {
        email: loginDto.email,
      } as any,
    });

    if (!user) {
      throw new BadRequestException('Invalid email or password');
    }

    const hashPassword = await BcryptEncryption.compare(
      loginDto.password,
      user.password,
    );
    if (!user || !hashPassword) {
      throw new BadRequestException('Invalid email or password');
    }

    return {
      message: 'User found successfully',
      status_code: 200,
      data: user,
    };
  }

  async update(id: string, updateUserDto: UpdateAdminDto) {
    try {
      const user = await this.prismaservice.user.findUnique({
        where: { user_id: id },
      });

      if (!user) {
        throw new BadRequestException('User not found');
      }

      if (updateUserDto?.password) {
        const hashPassword = await BcryptEncryption.encrypt(
          updateUserDto.password,
        );
      }

      const updatedUser = await this.prismaservice.user.update({
        where: { user_id: id },
        data: updateUserDto,
      });

      return {
        message: 'User updated successfully',
        status_code: 200,
        data: updatedUser,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async remove(id: string) {
    try {
      const user = await this.prismaservice.user.findUnique({
        where: { user_id: id },
      });

      if (!user) {
        throw new BadRequestException('User not found');
      }

      await this.prismaservice.user.delete({
        where: { user_id: id },
      });

      return {
        message: 'User deleted successfully',
        status_code: 200,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }
}
