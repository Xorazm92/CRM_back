import { FileValidationPipe } from '@/infrastructure/lib/file-validation-pipe/file.validation.pipe';
import {
  BadRequestException,
  Controller,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { FileuploadService } from './fileupload.service';

@Controller('fileupload')
export class FileuploadController {
  @Post('upload')
  @UseInterceptors(
    FileInterceptor('file', new FileuploadService().getMulterConfig()),
  )
  uploadFile(@UploadedFile() file: Express.Multer.File | undefined) {
    if (!file) {
      throw new BadRequestException('No file uploaded');
    }

    return {
      message: 'File uploaded successfully',
      url: `http://localhost:4000/static/${file.filename}`,
    };
  }
}
