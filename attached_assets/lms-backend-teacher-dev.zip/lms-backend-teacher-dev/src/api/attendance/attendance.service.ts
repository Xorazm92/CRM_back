import { HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '@/common/prisma/prisma.service';
import { CreateAttendanceDto } from './dto/create-attendance.dto';
import { UpdateAttendanceDto } from './dto/update-attendance.dto';
import { PaginationDto } from '@/common/dto';

@Injectable()
export class AttendanceService {
  constructor(private readonly prisma: PrismaService) {}
  async create(createAttendanceDto: CreateAttendanceDto) {
    try {
      const newAttendance = await this.prisma.attendance.create({
        data: createAttendanceDto,
      });
      return {
        status_code: HttpStatus.CREATED,
        message: 'Attendance created successfully',
        data: {
          attendace_id: newAttendance.attendance_id,
        },
      };
    } catch (error) {
      return error.message;
    }
  }

  async findAll(query: PaginationDto) {
    try {
      const { page, limit } = query;
      const skip = (page - 1) * limit;
      const [data, count] = await Promise.all([
        this.prisma.attendance.findMany({
          skip,
          take: limit,
        }),
        this.prisma.attendance.count(),
      ]);
      if (data.length == 0) {
        throw new NotFoundException('Attendeces not found');
      }
      return {
        status_code: HttpStatus.OK,
        message: 'All Attendance',
        data: data,
        filter: {
          limit,
          pageSize: Math.ceil(count / limit),
          totalItems: count,
        },
      };
    } catch (error) {
      return error.message;
    }
  }

  async findOne(id: string) {
    try {
      const data = await this.prisma.attendance.findFirst({
        where: { attendance_id: id },
      });
      if (!data) {
        throw new NotFoundException('Attendance not found');
      }
      return {
        status_code: HttpStatus.OK,
        message: 'One Attendance',
        data: {
          ...data,
        },
      };
    } catch (error) {
      return error.message;
    }
  }

  async update(id: string, updateAttendanceDto: UpdateAttendanceDto) {
    try {
      const data = await this.prisma.attendance.findFirst({
        where: { attendance_id: id },
      });
      if (!data) {
        throw new NotFoundException('Attendance not found');
      }
      await this.prisma.attendance.update({
        where: {
          attendance_id: id,
        },
        data: {
          ...updateAttendanceDto,
          updated_at: new Date(),
        },
      });
      return {
        status_code: HttpStatus.NO_CONTENT,
        message: 'Attendance updated successfully',
      };
    } catch (error) {
      return error.message;
    }
  }

  async remove(id: string) {
    try {
      const data = await this.prisma.attendance.findFirst({
        where: { attendance_id: id },
      });
      if (!data) {
        throw new NotFoundException('Attendance not found or deleted before');
      }
      return {
        status_code: HttpStatus.NO_CONTENT,
        message: 'Attendance deleted successfully',
      };
    } catch (error) {
      return error.message;
    }
  }
}
